#include <stdio.h>

int main()
{
	printf("Hello World, C!\n");

	return 0;
}
