1.    Run testbench (RSA_ZOIX\ZOIX_global\designs\RSA_tb.v) in VCS without -gui to dump a vcd file

2.    .sff file defines the fault list, use the sff_gen.py to generate .sff

3.    To run ZOIX: sh run.csh

4.    To observe the injected faults in waveform: 
If “./zoix.sim -fault +fault+machine+1 +vcd+file+input.vcd” in run.csh file is executed, you can get a vcd file with fault-machine's number in its name. Start VCS with “dve &” command and open this vcd file.