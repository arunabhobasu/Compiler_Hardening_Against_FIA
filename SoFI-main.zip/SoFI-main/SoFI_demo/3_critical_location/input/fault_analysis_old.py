#!/usr/bin/env python

from shutil import copyfile
import os
copyfile('/home/UFAD/huanyuwang/Documents/Fault_Injection/Host_Demo/Demo/3_critical_location/output/critical_faults.sff', 'critical_faults.sff')
