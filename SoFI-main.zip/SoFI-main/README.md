# SoFI

SoFI is a security property-driven fault injection assessment tool that can identify the critical locations in the gate-level netlist of ICs to fault injection attacks. 

**To run a demo:** check ./SoFI_demo/ and run "sh fault_injection_cmd.sh".

**Check SoFI_Work_Flow.pptx in ./Manuals_slides for more details.** A simple example regarding DFA attack scenario on RSA's FSM is given in ./SoFI_simple_example. Further information can be found in Z01X manuals.

Reference: H. Wang, H. Li, F. Rahman, M. M. Tehranipoor and F. Farahmandi, "SoFI: Security Property-Driven Vulnerability Assessments of ICs Against Fault-Injection Attacks," in IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems, doi: 10.1109/TCAD.2021.3063998.
