1. DFA_K9_tinyaes

Security Property: Any one byte of the first column on the 9th AES round key registers should not be faulty.

Reference: Kim, Chong Hee and Jean-Jacques Quisquater. “New Differential Fault Analysis on AES Key Schedule: Two Faults Are Enough.” CARDIS (2008)

DFA attack on AES 9th round key, assumed that one byte of the first column of the 9th round key is corrupted, with 8 pairs of good and faulty ciphertexts, entire 128bit of 10th round key can be retrieved. The initial secrect key can be easiliy calculated based on 10th round key.

2. DFA_M9_tinyaes

Security Property: The state inputs of AES 10th round should be correctly derived from the last round.

Reference: C. Roscian, J. Dutertre and A. Tria, "Frontside laser fault injection on cryptosystems - Application to the AES' last round -," 2013 IEEE International Symposium on Hardware-Oriented Security and Trust (HOST), 2013, pp. 119-124, doi: 10.1109/HST.2013.6581576.

DFA attack on AES state M9, using frontside laser to flip the bits of 9th round state registers, thus, making the 10th round AES inputs corrupted. Then, use Lashermes et al.'s DFA approach to retrieve the key.

3. FSM_avs_aes

Security Property: The DO_ROUND state of AES controller should be bypassed.

Reference: A. Nahiyan, F. Farahmandi, P. Mishra, D. Forte and M. Tehranipoor, "Security-Aware FSM Design Flow for Identifying and Mitigating Vulnerabilities to Fault Attacks," in IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems, vol. 38, no. 6, pp. 1003-1016, June 2019, doi: 10.1109/TCAD.2018.2834396.