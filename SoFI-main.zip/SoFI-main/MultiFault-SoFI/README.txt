To run:

sh run.csh

Fault-list generation script is ./sff_gen_fanin/sff_gen_fanin.py