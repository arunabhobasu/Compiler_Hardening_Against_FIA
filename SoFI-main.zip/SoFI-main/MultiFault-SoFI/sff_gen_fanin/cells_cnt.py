#!/usr/bin/env python

import io

filename = "secret.txt"

fid = open(filename)
temp = fid.read()
fanin_cells = temp.replace('/D',' ').split()
print ("Before sort:" + str(len(fanin_cells)))
fanin_cells = list(set(fanin_cells))    #Delete the duplicated elements
print ("After sort:" + str(len(fanin_cells)))
fid.close()
